INSTALLATION : 

D�zippez le contenu de l'archive dans le dossier Support Files/Scripts de After Effects.


CHANGELOG :

v1.2 :

IK 2+1 : lorsqu'un goal est cr�e, sa rotation est contr�l�e par celle du contr�leur.
Corrections de petits bugs, et optimisation du code.