INSTALLATION : 

D�zippez le contenu de l'archive dans le dossier Support Files/Scripts de After Effects.


CHANGELOG :

v4 : Correction du big qui inversait les axes X et Y sur le wiggle
Ajour de la fonction "roue"

v3 :
Ajout du bouton bone, qui permet de cr�er des bones sur des points de l'outil marionnette, bones qui peuvent alors recevoir des IK.
Correction d'un bug relatif � la longueur des noms des calques lors de l'application d'un IK.

v2 :
Ajout de la fonction Wiggle

v1.21 :
correction de bugs...

v1.2 :

IK 2+1 : lorsqu'un goal est cr�e, sa rotation est contr�l�e par celle du contr�leur.
Corrections de petits bugs, et optimisation du code.