INSTALLATION : 

D�zippez le contenu de l'archive dans le dossier Support Files/Scripts de After Effects.


CHANGELOG :

v6.1 : Petite am�lioration du morpher pour qu'il tienne compte du num�ro de la premi�re image de la composition

v6 : Ajout de la fonction "cam relief"

v5 : Ajout de la fonction "control cam"

v4 : Correction du big qui inversait les axes X et Y sur le wiggle
Ajour de la fonction "roue"

v3 :
Ajout du bouton bone, qui permet de cr�er des bones sur des points de l'outil marionnette, bones qui peuvent alors recevoir des IK.
Correction d'un bug relatif � la longueur des noms des calques lors de l'application d'un IK.

v2 :
Ajout de la fonction Wiggle

v1.21 :
correction de bugs...

v1.2 :

IK 2+1 : lorsqu'un goal est cr�e, sa rotation est contr�l�e par celle du contr�leur.
Corrections de petits bugs, et optimisation du code.